import turtle

t = turtle.Pen()

for i in range(3): # triangle
  t.forward(100)
  t.left(120)

turtle.done()
