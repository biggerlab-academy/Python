import turtle

t = turtle.Pen()
colours = ["red", "blue", "purple"]

for i in range(102):
  t.pencolor(colours[i % 3])
  t.forward(i)
  t.left(120)

turtle.done()
