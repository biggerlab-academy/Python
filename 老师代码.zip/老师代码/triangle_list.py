import turtle

t = turtle.Pen()
colours = ["red", "blue", "purple"]

for i in range(3):
  t.pencolor(colours[i])
  t.forward(100)
  t.left(120)

turtle.done()
