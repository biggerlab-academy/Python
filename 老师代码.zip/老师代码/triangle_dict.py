import turtle

t = turtle.Pen()
colours = {"SkyBlue": "#87CEEB", "Gold": "#FFD700", "Wheat": "#F5DEB3"}
keys = list(colours.keys())

for i in range(102):
  t.pencolor(colours[keys[i % 3]])
  t.forward(i)
  t.left(120)

turtle.done()
